package com.example.firstlab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

public class MainActivity2 extends AppCompatActivity {
    TextView name2;
    TextView age2;
    TextView gender2;
    LinearLayout background;
    Button bgButton;
    Button next2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        name2= (TextView) findViewById(R.id.textName);
        age2 = (TextView) findViewById(R.id.textAge);
        gender2 = (TextView) findViewById(R.id.textPol);
        background=(LinearLayout)findViewById(R.id.b1);
        bgButton = (Button) findViewById(R.id.buttonBackgroubd);
        next2 = (Button) findViewById(R.id.buttonNext);

        String userName = getIntent().getStringExtra("userName");

        String userAge = getIntent().getStringExtra("userAge");
        String userGender = getIntent().getStringExtra("userGender");

        name2.setText(name2.getText().toString() + " " + userName);
        age2.setText(age2.getText().toString() + " " + userAge);
        gender2.setText(gender2.getText().toString() + " " + userGender);


        bgButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Random random = new Random();
                int color = Color.argb(255, random.nextInt(256),random.nextInt(256),random.nextInt(256));
                background.setBackgroundColor(color);
            }
        });
        next2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                startActivity(intent);
            }
        });

    }
}