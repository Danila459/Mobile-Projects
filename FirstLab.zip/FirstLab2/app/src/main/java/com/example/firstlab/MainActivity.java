package com.example.firstlab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    EditText name;
    EditText age;
    RadioButton woman;
    RadioButton man;

    Button reset;
    Button next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name= (EditText) findViewById(R.id.editTextName);
        age = (EditText) findViewById(R.id.editTextAge);
        woman = (RadioButton) findViewById(R.id.radioFemale);
        man = (RadioButton) findViewById(R.id.radioMall);
        reset = (Button) findViewById(R.id.buttonReset);
        next = (Button) findViewById(R.id.buttonSend);
        reset.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                name.getText().clear();
                age.getText().clear();
                man.setChecked(false);
                woman.setChecked(false);
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (name.getText().length() != 0 && age.getText().length() != 0) {
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    intent.putExtra("userName", name.getText().toString());
                    intent.putExtra("userAge", age.getText().toString());
                    if (woman.isChecked())
                        intent.putExtra("userGender", woman.getText().toString());
                    else intent.putExtra("userGender", man.getText().toString());
                    startActivity(intent);
                }
            }
        });

    }

}