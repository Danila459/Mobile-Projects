package com.example.lab_04.db

class ListItem {
    var id: Int = 0
    var title: String? = null
    var content: String? = null
    var time: String? = null
    var tags: ArrayList<String> = ArrayList()
}
