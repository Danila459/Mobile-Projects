package com.example.lab_04

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.SearchView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.lab_04.db.Adapter
import com.example.lab_04.db.DBManager
import com.example.lab_04.db.IntentConstants
import kotlinx.coroutines.*


class MainActivity : AppCompatActivity() {
    val dbManager = DBManager(this)
    val adapter = Adapter(ArrayList(), this)
    private var job: Job? = null

    lateinit var rcView: RecyclerView
    lateinit var tvNoElements: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.title = ""
        init()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        val searchItem = menu?.findItem(R.id.app_bar_search)
        val searchView = searchItem?.actionView as SearchView
        searchView.queryHint = "Search"
        searchView.setOnQueryTextListener(object: SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                fillAdapter(newText!!)
                return true
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.titleNotes -> {
                Toast.makeText(this,"Notes", Toast.LENGTH_SHORT).show()
            }
            R.id.titleTags -> {
                Toast.makeText(this,"Tags", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, TagsActivity::class.java)
                startActivity(intent)
            }
        }
        return true
    }
    private fun init(){
        rcView = findViewById<RecyclerView>(R.id.rcView)
        val swapHelper = getSwapManager()
        swapHelper.attachToRecyclerView(rcView)
        rcView.layoutManager = LinearLayoutManager(this)
        rcView.adapter = adapter
    }

    private fun fillAdapter(text: String) {
        job?.cancel()
        job = CoroutineScope(Dispatchers.Main).launch {
            tvNoElements = findViewById(R.id.tvNoElements)
            val list = withContext(Dispatchers.IO) { dbManager.readDBData(text) }
            adapter.updateAdapter(list)
            if (list.size > 0) {
                tvNoElements.visibility = View.GONE
            } else {
                tvNoElements.visibility = View.VISIBLE
            }
        }
    }

    fun onClickAdd(view: View) {
        val i = Intent(this, EditActivity::class.java)
        startActivity(i)
    }
    private fun getSwapManager(): ItemTouchHelper{

        return ItemTouchHelper(object: ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT or ItemTouchHelper.LEFT){
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                adapter.removeItem(viewHolder.adapterPosition, dbManager)

            }

        })
    }
    override fun onResume() {
        super.onResume()
        dbManager.openDB()
        fillAdapter("")

    }

    override fun onDestroy() {
        super.onDestroy()
        dbManager.closeDB()
    }
}
