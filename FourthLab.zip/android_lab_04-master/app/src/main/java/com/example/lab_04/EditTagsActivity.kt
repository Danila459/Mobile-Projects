package com.example.lab_04

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.example.lab_04.db.DBManager
import com.example.lab_04.db.IntentConstants
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class EditTagsActivity : AppCompatActivity() {
    val dbManager = DBManager(this)
    var id = 0
    lateinit var edTag: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_tags)
        edTag = findViewById(R.id.edTag)
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_edit, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.titleDelete -> {
                Toast.makeText(this,"Deleted", Toast.LENGTH_SHORT).show()
                CoroutineScope(Dispatchers.Main).launch {
                    //dbManager.deleteTag(id)
                    //dbManager.unlinkTagsFromNote(id)
                    finish()
                }
            }
            R.id.titleCancel -> {
                Toast.makeText(this,"Canceled", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
        return true
    }

    fun onClickSaveTags(view: View) {
        val myTag = edTag.text.toString()

        if(myTag != ""){
            CoroutineScope(Dispatchers.Main).launch {
                var res = dbManager.createTag(myTag)
                if (res) {
                    finish()
                } else Toast.makeText(getApplicationContext(), "Tag must be in one world", Toast.LENGTH_SHORT).show()
            }
        }
    }
    override fun onResume() {
        super.onResume()
        dbManager.openDB()
    }
    override fun onDestroy() {
        super.onDestroy()
        dbManager.closeDB()
    }

}