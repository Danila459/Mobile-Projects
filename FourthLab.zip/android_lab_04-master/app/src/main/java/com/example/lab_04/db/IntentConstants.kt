package com.example.lab_04.db

object IntentConstants {
    const val I_TITLE_KEY = "title_key"
    const val I_CONTENT_KEY = "content_key"
    const val I_ID_KEY = "id_key"
    const val I_TAGS_KEY = "tags_key"
    const val I_TAGS_ID_KEY = "tags_id_key"
}