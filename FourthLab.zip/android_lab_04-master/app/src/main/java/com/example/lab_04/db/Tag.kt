package com.example.lab_04.db

import android.os.Parcel
import android.os.Parcelable

class Tag(public val id: Long, public val text: String) : Parcelable {
    init {
    }

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeLong(id)
        dest.writeString(text)
    }

    constructor(parcel: Parcel) : this(parcel.readLong(), parcel.readString()!!)

    companion object CREATOR : Parcelable.Creator<Tag> {
        override fun createFromParcel(parcel: Parcel): Tag {
            return Tag(parcel)
        }

        override fun newArray(size: Int): Array<Tag?> {
            return arrayOfNulls(size)
        }
    }
}
