package com.example.lab_04

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.SearchView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.lab_04.db.Adapter
import com.example.lab_04.db.AdapterTags
import com.example.lab_04.db.DBManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TagsActivity : AppCompatActivity() {
    val dbManager = DBManager(this)
    val adapter = AdapterTags( this,ArrayList())
    lateinit var tvNoTags: TextView
    lateinit var rcViewTags: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tags)
        supportActionBar?.title = ""
        init()
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        val searchItem = menu?.findItem(R.id.app_bar_search)
        val searchView = searchItem?.actionView as SearchView
        searchView.queryHint = "Search"
        searchView.setOnQueryTextListener(object: SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                fillAdapter(newText!!)
                return true
            }
        })
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.titleNotes -> {
                Toast.makeText(this,"Notes", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
            R.id.titleTags -> {
                Toast.makeText(this,"Tags", Toast.LENGTH_SHORT).show()

            }
        }
        return true
    }
    private fun init(){
        rcViewTags = findViewById<RecyclerView>(R.id.rc_tags)
        rcViewTags.layoutManager = LinearLayoutManager(this)
        rcViewTags.adapter = adapter
        val swapHelper = getSwapManager()
        swapHelper.attachToRecyclerView(rcViewTags)
    }
    private fun fillAdapter(text: String){
        CoroutineScope(Dispatchers.Main).launch{
            tvNoTags = findViewById(R.id.tvNoTags)
            val list = dbManager.readAllTags()
            adapter.updateAdapter(list)
            if(list.size > 0) {tvNoTags.visibility = View.GONE}
            else {tvNoTags.visibility = View.VISIBLE}
        }
    }

    fun onClickAdd(view: View) {
        val i = Intent(this, EditTagsActivity::class.java)
        startActivity(i)
    }
    private fun getSwapManager(): ItemTouchHelper {

        return ItemTouchHelper(object: ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT or ItemTouchHelper.LEFT){
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                adapter.removeTags(viewHolder.adapterPosition, dbManager)

            }

        })
    }
    override fun onResume() {
        super.onResume()
        dbManager.openDB()
        fillAdapter("")
    }

    override fun onDestroy() {
        super.onDestroy()
        dbManager.closeDB()
    }

}