package com.example.lab_04.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper (context: Context) : SQLiteOpenHelper (context, MyDBNameClass.DATABASE_NAME,
    null, MyDBNameClass.DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(MyDBNameClass.CREATE_TABLE)
        db?.execSQL(MyDBNameClass.CREATE_TABLE_TAGS)
        db?.execSQL(MyDBNameClass.CREATE_TABLE_NOTE_TAGS)

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL(MyDBNameClass.DELETE_TABLE)
        db?.execSQL(MyDBNameClass.DELETE_TABLE_TAGS)
        db?.execSQL(MyDBNameClass.DELETE_TABLE_NOTE_TAGS)
        onCreate(db)
    }

}