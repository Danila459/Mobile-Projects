package com.example.lab_04

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.example.lab_04.db.DBManager
import com.example.lab_04.db.IntentConstants
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class EditActivity : AppCompatActivity() {
    val selectedTags: ArrayList<String> = ArrayList()
    val dbManager = DBManager(this)
    var id = 0
    var isEditState = false
    lateinit var edTitle: EditText
    lateinit var edContent: EditText
    lateinit var fbEdit: FloatingActionButton
    lateinit var chipGroup: ChipGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)
        supportActionBar?.title = ""
        edTitle = findViewById(R.id.edTitle)
        edContent = findViewById(R.id.edContent)
        fbEdit = findViewById(R.id.fbEdit)
        chipGroup = findViewById(R.id.chipGroup)
        getMyIntents()
        CoroutineScope(Dispatchers.Main).launch {
            createTagList()
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_edit, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.titleDelete -> {
                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
                CoroutineScope(Dispatchers.Main).launch {
                    dbManager.removeItemFromDB(id.toString())
                    dbManager.removeTagsForNoteFromDB(id)
                    finish()
                }
            }
            R.id.titleCancel -> {
                Toast.makeText(this, "Canceled", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
        return true
    }
    private fun createTagList() {
        val tags = dbManager.readAllTags()
        for (tag in tags) {
            val chip = Chip(this)
            chip.text = tag.text
            chip.isCheckable = true
            chipGroup.addView(chip)

            if (isEditState && selectedTags.contains(tag.text)) {
                chip.isChecked = true
            }

            if (!isEditState) {
                chip.isClickable = true
                chip.setOnCheckedChangeListener { buttonView, isChecked ->
                    if (isChecked) {
                        selectedTags.add(tag.text)
                    } else {
                        selectedTags.remove(tag.text)
                    }
                }
            } else {
                chip.isClickable = false
            }
        }
    }
    private fun getMyIntents() {
        val i = intent
        fbEdit.visibility = View.GONE
        if (i != null) {
            if (i.getStringExtra(IntentConstants.I_TITLE_KEY) != null) {
                isEditState = true
                edTitle.setText(i.getStringExtra(IntentConstants.I_TITLE_KEY))
                edContent.setText(i.getStringExtra(IntentConstants.I_CONTENT_KEY))
                id = i.getIntExtra(IntentConstants.I_ID_KEY, 0)
                fbEdit.visibility = View.VISIBLE

                for (j in 0 until chipGroup.childCount) {
                    val chip = chipGroup.getChildAt(j) as Chip
                    if (!isEditState || fbEdit.visibility == View.VISIBLE) {
                        chip.isClickable = true
                    }
                    if (i.getStringArrayListExtra(IntentConstants.I_TAGS_ID_KEY)?.contains(chip.text.toString()) == true) {
                        chip.isChecked = true
                        selectedTags.add(chip.text.toString())
                    }
                }
            }
        }
    }
    private fun getCurrentTime(): String {
        val time = Calendar.getInstance().time
        val formatter = SimpleDateFormat("dd MMMM YYYY", Locale.getDefault())
        return formatter.format(time)
    }

    override fun onResume() {
        super.onResume()
        dbManager.openDB()
    }

    override fun onDestroy() {
        super.onDestroy()
        dbManager.closeDB()
    }

    fun onClickSave(view: View) {
        val myTitle = edTitle.text.toString()
        val myContent = edContent.text.toString()

        if (myTitle != "" && myContent != "") {
            CoroutineScope(Dispatchers.Main).launch {
                var noteId = id
                if (isEditState) {
                    noteId = id
                    dbManager.updateItem(myTitle, myContent, id, getCurrentTime())
                    saveNoteWithTags(noteId, selectedTags)
                } else {
                    noteId = dbManager.insertToDB(myTitle, myContent, getCurrentTime()).toInt()
                    saveNoteWithTags(noteId, selectedTags)
                }
                finish()
            }
        }
    }

    private fun saveNoteWithTags(noteId: Int, selectedTags: ArrayList<String>) {
        if (selectedTags.isNotEmpty()) {
            val tagIds = dbManager.getTagIds(selectedTags)
            dbManager.insertTagForNoteToDB(noteId, tagIds)
        }
    }

    fun onClickEdit(view: View) {
        fbEdit.visibility = View.GONE
        edTitle.isEnabled = true
        edContent.isEnabled = true
        for (j in 0 until chipGroup.childCount) {
            val chip = chipGroup.getChildAt(j) as Chip
            chip.isClickable = true
            chip.setOnCheckedChangeListener { buttonView, isChecked ->
                if (isChecked) {
                    selectedTags.add(chip.text as String)
                } else {
                    selectedTags.remove(chip.text)
                }
            }
        }

        dbManager.removeTagsForNoteFromDB(id)
        saveNoteWithTags(id, selectedTags)
    }
}