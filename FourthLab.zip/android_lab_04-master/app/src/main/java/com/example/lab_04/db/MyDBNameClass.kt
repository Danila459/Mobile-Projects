package com.example.lab_04.db

import android.provider.BaseColumns

object MyDBNameClass {
    const val TABLE_NAME = "notes"
    const val COLUMN_NAME_TITLE = "title"
    const val COLUMN_NAME_CONTENT = "content"
    const val COLUMN_NAME_TIME = "time"

    const val TABLE_TAGS = "tags"
    const val TABLE_NOTE_TAGS = "note_tags"

    const val COLUMN_TAG_ID = "id"
    const val COLUMN_TAG_NAME = "name"

    const val COLUMN_KEY_NOTE_ID = "note_id"
    const val COLUMN_TAG_NOTE_ID = "tag_id"

    const val DATABASE_VERSION = 1
    const val DATABASE_NAME = "NotebookDB.db"

    const val CREATE_TABLE = "CREATE TABLE IF NOT EXISTS $TABLE_NAME (" +
            "${BaseColumns._ID} INTEGER PRIMARY KEY, $COLUMN_NAME_TITLE TEXT, " +
            "$COLUMN_NAME_CONTENT TEXT,$COLUMN_NAME_TIME TEXT)"


    const val CREATE_TABLE_TAGS = "CREATE TABLE IF NOT EXISTS $TABLE_TAGS (" +
            "$COLUMN_TAG_ID INTEGER PRIMARY KEY AUTOINCREMENT, $COLUMN_TAG_NAME TEXT)"

    const val CREATE_TABLE_NOTE_TAGS = ("CREATE TABLE " + TABLE_NOTE_TAGS + "("
            + COLUMN_KEY_NOTE_ID + " INTEGER,"
            + COLUMN_TAG_NOTE_ID + " INTEGER,"
            + "FOREIGN KEY(" + COLUMN_KEY_NOTE_ID + ") REFERENCES " + TABLE_NAME + "(" + "${BaseColumns._ID}" + "),"
            + "FOREIGN KEY(" + COLUMN_TAG_NOTE_ID + ") REFERENCES " + TABLE_TAGS + "(" + COLUMN_TAG_NOTE_ID + "))")


    const val DELETE_TABLE = "DROP TABLE IF EXISTS ${TABLE_NAME}"
    const val DELETE_TABLE_TAGS = "DROP TABLE IF EXISTS ${TABLE_TAGS}"
    const val DELETE_TABLE_NOTE_TAGS = "DROP TABLE IF EXISTS ${TABLE_NOTE_TAGS}"

}