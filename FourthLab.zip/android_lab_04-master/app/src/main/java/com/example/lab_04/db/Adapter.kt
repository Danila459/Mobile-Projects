package com.example.lab_04.db

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.lab_04.EditActivity
import com.example.lab_04.R

class Adapter(listMain: ArrayList<ListItem>, contextM: Context, ): RecyclerView.Adapter<Adapter.Holder>() {
    var listArray = listMain
    var context = contextM

    class Holder(itemView: View, context: Context) : RecyclerView.ViewHolder(itemView) {
        val tvTitle = itemView.findViewById<TextView>(R.id.tvTitle)
        val tvTime = itemView.findViewById<TextView>(R.id.tv_time)
        val tvContent = itemView.findViewById<TextView>(R.id.tvNotes)
        val tvTagsNote = itemView.findViewById<TextView>(R.id.tvTagsNote)
        val context = context

        fun setData(item: ListItem){
            tvTitle.text = item.title
            tvTime.text = item.time
            tvContent.text = item.content
            var stringTags = ""
            for(item in item.tags){
                stringTags += "$item, "
            }
            if (stringTags.isNotEmpty()) {
                stringTags = stringTags.substring(0, stringTags.length - 2)
            }
            tvTagsNote.text = stringTags
            Log.d("TAG", item.tags.toString())
            itemView.setOnClickListener{
                val intent = Intent(context, EditActivity::class.java).apply {
                    putExtra(IntentConstants.I_TITLE_KEY, item.title)
                    putExtra(IntentConstants.I_CONTENT_KEY, item.content)
                    putExtra(IntentConstants.I_ID_KEY, item.id)
                    putExtra(IntentConstants.I_TAGS_KEY,item.tags)
                }
                context.startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val inflater = LayoutInflater.from(parent.context)
        return Holder(inflater.inflate(R.layout.rc_item, parent, false), context)
    }

    override fun getItemCount(): Int {
        return listArray.size
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder.setData(listArray[position])
    }

    fun updateAdapter(listItems: List<ListItem>){
        listArray.clear()
        listArray.addAll(listItems)
        notifyDataSetChanged()
    }

    fun removeItem(pos: Int, dbManager: DBManager){
        dbManager.removeItemFromDB(listArray[pos].id.toString())
        dbManager.removeTagsForNoteFromDB(listArray[pos].id)
        listArray.removeAt(pos)
        notifyItemRangeChanged(0,listArray.size)
        notifyItemRemoved(pos)
    }
}