package com.example.lab_04.db

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.provider.BaseColumns
import android.util.Log
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DBManager (context: Context) {
    val DBHelper = DBHelper(context)
    var db: SQLiteDatabase? = null

    fun openDB() {
        db = DBHelper.writableDatabase
    }

    suspend fun insertToDB(title: String, content: String, time: String): Long = withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put(MyDBNameClass.COLUMN_NAME_TITLE, title)
            put(MyDBNameClass.COLUMN_NAME_CONTENT, content)
            put(MyDBNameClass.COLUMN_NAME_TIME, time)
        }
        return@withContext db!!.insertWithOnConflict(MyDBNameClass.TABLE_NAME, null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun removeItemFromDB(id: String) {
        var selection = BaseColumns._ID + "=$id"
        db?.delete(MyDBNameClass.TABLE_NAME, selection, null)

        selection = "${MyDBNameClass.COLUMN_KEY_NOTE_ID} = ?"
        db?.delete(MyDBNameClass.TABLE_NOTE_TAGS, selection, arrayOf(id))
    }

    @SuppressLint("Range")
    suspend fun readDBData(searchText: String): ArrayList<ListItem> = withContext(Dispatchers.IO) {
        val dataList = ArrayList<ListItem>()
        val selectionNote = "${MyDBNameClass.COLUMN_NAME_TITLE} like ?"
        val cursor = db?.query(
            MyDBNameClass.TABLE_NAME, null,
            selectionNote, arrayOf("%$searchText%"), null, null, null
        )

        while (cursor?.moveToNext()!!) {
            val dataTitle = cursor.getString(cursor.getColumnIndex(MyDBNameClass.COLUMN_NAME_TITLE))
            val dataContent = cursor.getString(cursor.getColumnIndex(MyDBNameClass.COLUMN_NAME_CONTENT))
            val dataTime = cursor.getString(cursor.getColumnIndex(MyDBNameClass.COLUMN_NAME_TIME))
            val dataID = cursor.getInt(cursor.getColumnIndex(BaseColumns._ID))
            val tagIds = ArrayList<Int>()
            val selectionTag = "${MyDBNameClass.COLUMN_KEY_NOTE_ID} = ?"
            val tagCursor = db?.query(
                MyDBNameClass.TABLE_NOTE_TAGS,
                arrayOf(MyDBNameClass.COLUMN_KEY_NOTE_ID, MyDBNameClass.COLUMN_TAG_NOTE_ID),
                selectionTag,
                arrayOf(dataID.toString()),
                null,
                null,
                null
            )
            while (tagCursor?.moveToNext()!!) {
                val tagId = tagCursor.getInt(tagCursor.getColumnIndex(MyDBNameClass.COLUMN_TAG_NOTE_ID))
                tagIds.add(tagId)
            }
            tagCursor.close()

            var item = ListItem()
            item.title = dataTitle
            item.content = dataContent
            item.time = dataTime
            item.id = dataID
            var stringTags= ArrayList<String>()
            for(tagId in tagIds) {
                val selection = "${MyDBNameClass.COLUMN_TAG_ID} = ?"
                val cursor = db?.query(MyDBNameClass.TABLE_TAGS, arrayOf(MyDBNameClass.COLUMN_TAG_NAME), selection, arrayOf(tagId.toString()), null, null, null)
                cursor?.moveToFirst()
                val tagName = cursor?.getString(cursor.getColumnIndex(MyDBNameClass.COLUMN_TAG_NAME))
                if (tagName != null) {
                    stringTags.add(tagName.toString())
                }
                cursor?.close()
            }
            item.tags = stringTags
            Log.d("TAG1", item.tags.toString())
            dataList.add(item)
        }
        cursor.close()
        return@withContext dataList
    }

    suspend fun updateItem(title: String, content: String, id: Int, time: String) =
        withContext(Dispatchers.IO) {
            var selection = BaseColumns._ID + "=$id"
            val values = ContentValues().apply {
                put(MyDBNameClass.COLUMN_NAME_TITLE, title)
                put(MyDBNameClass.COLUMN_NAME_CONTENT, content)
                put(MyDBNameClass.COLUMN_NAME_TIME, time)

            }
            db?.update(MyDBNameClass.TABLE_NAME, values, selection, null)

        }

    fun closeDB() {
        DBHelper.close()
    }

    fun  createTag(textTag: String): Boolean {
        if (!textTag.matches("\\w+".toRegex())) {
            return false
        }

        val values = ContentValues().apply {
            put(MyDBNameClass.COLUMN_TAG_NAME, textTag)
        }
        db?.insert(MyDBNameClass.TABLE_TAGS, null, values)
        return true
    }
    @SuppressLint("Range")
    fun readAllTags(): ArrayList<Tag> {
        val tags = ArrayList<Tag>()
        val cursor = db?.query(MyDBNameClass.TABLE_TAGS, null, null, null, null, null, null)
        while (cursor?.moveToNext()!!) {
            val id = cursor.getLong(cursor.getColumnIndex(MyDBNameClass.COLUMN_TAG_ID))
            val text = cursor.getString(cursor.getColumnIndex(MyDBNameClass.COLUMN_TAG_NAME))
            tags.add(Tag(id, text))
        }
        cursor.close()
        return tags
    }

    fun insertTagForNoteToDB(noteId: Int, tagIds: List<Long>): List<Long> {
        val insertedIds = mutableListOf<Long>()
        tagIds.forEach { tagId ->
            val values = ContentValues().apply {
                put(MyDBNameClass.COLUMN_KEY_NOTE_ID, noteId)
                put(MyDBNameClass.COLUMN_TAG_NOTE_ID, tagId)
            }
            val id = db?.insert(MyDBNameClass.TABLE_NOTE_TAGS, null, values)
            if (id != null && id != -1L) {
                insertedIds.add(id)
            }
        }
        return insertedIds
    }

    fun removeTagsForNoteFromDB(noteId: Int) {
        val selection = "${MyDBNameClass.COLUMN_KEY_NOTE_ID} = ?"
        db?.delete(MyDBNameClass.TABLE_NOTE_TAGS, selection, arrayOf(noteId.toString()))
    }

    fun deleteTag(id: Int) {
        db!!.delete(
            MyDBNameClass.TABLE_TAGS,
            "${MyDBNameClass.COLUMN_TAG_ID} = ?",
            arrayOf(id.toString())
        )
    }

    fun getTagIds(selectedTags: List<String>): List<Long> {
        val tagIds = ArrayList<Long>()
        val selection = "${MyDBNameClass.COLUMN_TAG_NAME} IN (${selectedTags.joinToString { "'$it'" }})"
        val projection = arrayOf(MyDBNameClass.COLUMN_TAG_ID)
        val cursor = db!!.query(
            MyDBNameClass.TABLE_TAGS,
            projection,
            selection,
            null,
            null,
            null,
            null
        )
        cursor.use {
            while (cursor.moveToNext()) {
                tagIds.add(cursor.getLong(cursor.getColumnIndexOrThrow(MyDBNameClass.COLUMN_TAG_ID)))
            }
        }
        return tagIds
    }

}