package com.example.lab_04.db

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.lab_04.R

class AdapterTags(сontext: Context, tagList: ArrayList<Tag>) :
    RecyclerView.Adapter<AdapterTags.Holder>() {
    var tagList = tagList
    var сontext = сontext

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val inflater = LayoutInflater.from(parent.context)
        return Holder(inflater.inflate(R.layout.rc_tags, parent, false), сontext)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val tag = tagList[position]
        holder.bind(tag)
    }

    override fun getItemCount() = tagList.size

    fun updateAdapter(newTagList: List<Tag>) {
        tagList.clear()
        tagList.addAll(newTagList)
        notifyDataSetChanged()
    }

    fun removeTags(pos: Int, dbManager: DBManager){
        dbManager.deleteTag(tagList[pos].id.toInt())
        tagList.removeAt(pos)
        notifyItemRangeChanged(0,tagList.size)
        notifyItemRemoved(pos)
    }
    class Holder(itemView: View, private val context: Context) : RecyclerView.ViewHolder(itemView) {
        fun bind(tag: Tag) {
            itemView.findViewById<TextView>(R.id.tvTags).text = tag.text

        }
    }

}
