package com.example.labthird

import android.content.res.Configuration
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {

    var Check = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val Radiogroup1 = findViewById<RadioGroup>(R.id.radiogroup1)
        val Radiogroup2 = findViewById<RadioGroup>(R.id.radiogroup2)

        Radiogroup1.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { _, checkedId  ->
            if (checkedId != 1 && Check) {
                val radioButton = findViewById<RadioButton>(checkedId).text.toString()
                println(radioButton)
                convertLenght(radioButton, checkedId)
                Check = false
                Radiogroup1.clearCheck()
            } else Check = true
        })
        Radiogroup2.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { _, checkedId ->
            if (checkedId != 1 && Check) {
                val radioButton = findViewById<RadioButton>(checkedId).text.toString()
                println(radioButton)
                convertLenght(radioButton, checkedId)
                Check = false
                Radiogroup2.clearCheck()
            } else Check = true
        })
    }

    fun convertKM(input: Double) {
        val resMetr = findViewById<TextView>(R.id.Metr)
        resMetr.setText("%.3f".format((input * 1000)).toString())
        val resCM = findViewById<TextView>(R.id.cantimetr)
        resCM.setText("%.3f".format((input * 100000)).toString())
        val resMill = findViewById<TextView>(R.id.Mill)
        resMill.setText("%.3f".format((input * 0.621371)).toString())
        val resFut = findViewById<TextView>(R.id.Fut)
        resFut.setText("%.3f".format((input * 3280)).toString())
        val resDum = findViewById<TextView>(R.id.Dum)
        resDum.setText("%.3f".format((input * 39370)).toString())
        val resKM = findViewById<TextView>(R.id.kilometr)
        resKM.setText((input).toString())
    }

    fun convertMetr(input: Double) {
        val resMetr = findViewById<TextView>(R.id.Metr)
        resMetr.setText((input).toString())
        val resCM = findViewById<TextView>(R.id.cantimetr)
        resCM.setText("%.3f".format((input * 100)).toString())
        val resMill = findViewById<TextView>(R.id.Mill)
        resMill.setText("%.3f".format((input * 0.000621371)).toString())
        val resFut = findViewById<TextView>(R.id.Fut)
        resFut.setText("%.3f".format((input * 3.28084)).toString())
        val resDum = findViewById<TextView>(R.id.Dum)
        resDum.setText("%.3f".format((input * 39.3701)).toString())
        val resKM = findViewById<TextView>(R.id.kilometr)
        resKM.setText("%.3f".format((input / 1000)).toString())
    }

    fun convertCM(input: Double) {
        val resMetr = findViewById<TextView>(R.id.Metr)
        resMetr.setText("%.3f".format((input / 100)).toString())
        val resCM = findViewById<TextView>(R.id.cantimetr)
        resCM.setText("%.3f".format((input)).toString())
        val resMill = findViewById<TextView>(R.id.Mill)
        resMill.setText("%.3f".format((input * 0.00000621371)).toString())
        val resFut = findViewById<TextView>(R.id.Fut)
        resFut.setText("%.3f".format((input * 0.0328084)).toString())
        val resDum = findViewById<TextView>(R.id.Dum)
        resDum.setText("%.3f".format((input * 0.393701)).toString())
        val resKM = findViewById<TextView>(R.id.kilometr)
        resKM.setText("%.3f".format((input / 100000)).toString())
    }

    fun convertMill(input: Double) {
        val resMetr = findViewById<TextView>(R.id.Metr)
        resMetr.setText("%.3f".format((input / 0.000621371)).toString())
        val resCM = findViewById<TextView>(R.id.cantimetr)
        resCM.setText("%.3f".format((input * 160934)).toString())
        val resMill = findViewById<TextView>(R.id.Mill)
        resMill.setText((input).toString())
        val resFut = findViewById<TextView>(R.id.Fut)
        resFut.setText("%.3f".format((input * 5280)).toString())
        val resDum = findViewById<TextView>(R.id.Dum)
        resDum.setText("%.3f".format((input * 63360)).toString())
        val resKM = findViewById<TextView>(R.id.kilometr)
        resKM.setText("%.3f".format(input / 0.621371).toString())
    }

    fun convertFut(input: Double) {
        val resMetr = findViewById<TextView>(R.id.Metr)
        resMetr.setText("%.3f".format((input / 3.28084)).toString())
        val resCM = findViewById<TextView>(R.id.cantimetr)
        resCM.setText("%.3f".format((input * 30.48)).toString())
        val resMill = findViewById<TextView>(R.id.Mill)
        resMill.setText("%.3f".format((input * 0.00018939)).toString())
        val resFut = findViewById<TextView>(R.id.Fut)
        resFut.setText((input).toString())
        val resDum = findViewById<TextView>(R.id.Dum)
        resDum.setText("%.3f".format((input * 12)).toString())
        val resKM = findViewById<TextView>(R.id.kilometr)
        resKM.setText("%.3f".format((input / 3280)).toString())
    }

    fun convertDum(input: Double) {
        val resMetr = findViewById<TextView>(R.id.Metr)
        resMetr.setText("%.3f".format((input / 39.3701)).toString())
        val resCM = findViewById<TextView>(R.id.cantimetr)
        resCM.setText("%.3f".format((input * 2.54)).toString())
        val resMill = findViewById<TextView>(R.id.Mill)
        resMill.setText("%.3f".format((input * 0.000015783)).toString())
        val resFut = findViewById<TextView>(R.id.Fut)
        resFut.setText("%.3f".format((input * 0.083333)).toString())
        val resDum = findViewById<TextView>(R.id.Dum)
        resDum.setText((input).toString())
        val resKM = findViewById<TextView>(R.id.kilometr)
        resKM.setText("%.3f".format((input / 39370)).toString())
    }

    fun convertLenght(radioButton:String, id: Int) {
        val inputEditText: EditText = findViewById(R.id.EditText)
        val input = inputEditText.text.toString().toDouble()
        val result = when (radioButton) {
            getString(R.string.kilometr) -> convertKM(input)
            getString(R.string.meters) -> convertMetr(input)
            getString(R.string.cantimetr) -> convertCM(input)
            getString(R.string.Mill) -> convertMill(input)
            getString(R.string.Fut) -> convertFut(input)
            getString(R.string.Dum) -> convertDum(input)
            else -> {
            }
        }
    }
}